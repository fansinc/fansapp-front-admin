<?php

return [


    'url' => 'http://fansinc-api.hridham.com/',
    'storage'=>'http://fansinc-api.hridham.com/storage'


    // 'url' => 'http://api.getstaysavvy.co.uk/',
    // 'storage'=>'http://api.getstaysavvy.co.uk/storage'


]

?>
